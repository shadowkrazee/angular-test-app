import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cryptic',
  templateUrl: './cryptic.component.html',
  styleUrls: ['./cryptic.component.css']
})
export class CrypticComponent implements OnInit {
  plaintext: string;
  cyphertext: string;
  chars: string[];
  constructor() {}
  ngOnInit() {
    this.plaintext = '';
    this.cyphertext = '';
    this.chars = [
      'a',
      'b',
      'c',
      'd',
      'e',
      'f',
      'g',
      'h',
      'i',
      'j',
      'k',
      'l',
      'm',
      'n',
      'o',
      'p',
      'q',
      'r',
      's',
      't',
      'u',
      'v',
      'w',
      'x',
      'y',
      'z'
    ];
  }

  crypto(flag) {
    this.cyphertext = this.cyphertext.toLowerCase();
    let charpos;
    let corrpos;
    if (flag === 'd') {
      console.log('decrypting!');
      const decrypted = [];
      // decrypt here :
      const split = Array.from(this.cyphertext);
      const cpchars = this.chars;
      split.forEach(function(char) {
        if (char === ' ') {
          decrypted.push(' ');
        } else {
          cpchars.forEach(function(current, index) {
            if (char === current) {
              charpos = index;
              // console.log('p ' + charpos);
              corrpos = (21 * (charpos - 8)) % 26;
              if (corrpos < 0) {
                corrpos = 26 + corrpos;
              }
              // console.log('cp: ' + corrpos);
            }
          });
          decrypted.push(cpchars[corrpos]);
        }
      });
      this.plaintext = decrypted.join('');
    } else {
      console.log('encrypting!');
      // do reverse, and encrypt here
      const encrypted = [];
      const split = Array.from(this.plaintext);
      const cpchars = this.chars;
      split.forEach(function(char) {
        if (char === ' ') {
          encrypted.push(' ');
        } else {
          cpchars.forEach(function(current, index) {
            if (char === ' ') {
              encrypted.push(' ');
            } else if (char === current) {
              charpos = index;
              // console.log('p: ' + charpos);
              corrpos = (5 * charpos + 8) % 26;
              if (corrpos < 0) {
                corrpos = 26 + corrpos;
              }
              // console.log('cp: ' + corrpos);
            }
          });
          encrypted.push(cpchars[corrpos]);
        }
      });
      this.cyphertext = encrypted.join('');
    }
  }
}
